define(function(){
    return {
        pageGroups: [{"id":"06d3fb7d-e68d-393e-d46b-f78a0336773e","name":"Default group","pages":[{"id":"6b42d482-7aaa-799e-498b-287e62126e40","name":"Main"},{"id":"1aeb1a0e-3f1d-b864-e325-0af66f3d612e","name":"Products"}]}],
        downloadLink: "//services.ninjamock.com/html/htmlExport/download?shareCode=KN2LD&projectName=shop",
        startupPageId: 0,

        forEachPage: function(func, thisArg){
        	for (var i = 0, l = this.pageGroups.length; i < l; ++i){
                var group = this.pageGroups[i];
                for (var j = 0, k = group.pages.length; j < k; ++j){
                    var page = group.pages[j];
                    if (func.call(thisArg, page) === false){
                    	return;
                    }
                }
            }
        },
        findPageById: function(pageId){
        	var result;
        	this.forEachPage(function(page){
        		if (page.id === pageId){
        			result = page;
        			return false;
        		}
        	});
        	return result;
        }
    }
});
